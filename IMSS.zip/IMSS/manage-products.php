<?php
include 'connection.php';

// Handle delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $delete_sql = "DELETE FROM products WHERE id = $id";
    if (mysqli_query($conn, $delete_sql)) {
        header("Location: products.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

// Fetch products
$result = mysqli_query($conn, "SELECT * FROM products ORDER BY id ASC");
if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - Products</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Bootstrap & FontAwesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="d-flex">
    <!-- Sidebar -->
    <nav class="sidebar bg-dark text-white vh-100">
        <div class="sidebar-header bg-danger p-3">
            <h5 class="mb-0">INVENTORY SYSTEM</h5>
        </div>
        <ul class="nav flex-column mt-3">
            <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
            <li class="nav-item"><a href="manage-group.php" class="nav-link text-white"><i class="fas fa-user me-2"></i> User Management</a></li>
            <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
            <li class="nav-item"><a href="products.php" class="nav-link text-white active"><i class="fas fa-box me-2"></i> Products</a></li>
            <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
            <li class="nav-item"><a href="sales.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
            <li class="nav-item"><a href="sales-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i>Outbound Report</a></li>
        </ul>
    </nav>

    <!-- Main Content -->
    <div class="p-4 flex-grow-1">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h4 class="mb-0">PRODUCTS</h4>
            <a href="add_product.php" class="btn btn-primary">
                <i class="fas fa-plus"></i> Add New Product
            </a>
        </div>

        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Model</th>
                    <th>Quantity</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php 
              $rowNumber = 1;
              while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?= $rowNumber ?></td>
                    <td><?= htmlspecialchars($row['product']) ?></td>
                    <td><?= htmlspecialchars($row['model']) ?></td>
                    <td><?= htmlspecialchars($row['quantity']) ?></td>
                    <td>
                        <a href="edit_product.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-pen"></i>
                        </a>
                        <a href="products.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this product?')" class="btn btn-danger btn-sm">
                            <i class="fas fa-times"></i>
                        </a>
                    </td>
                </tr>
             <?php 
                $rowNumber++;
              endwhile; ?>
            </tbody>
        </table>
    </div>
</div>
<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
