
<?php 
session_start();  
include 'connection.php';  

// Users count
$result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM userAdd"));
$users_count = isset($result['total']) ? $result['total'] : 0;

// Categories count
$result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM categories"));
$categories_count = isset($result['total']) ? $result['total'] : 0;

// Products count
$result = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) AS total FROM products"));
$products_count = isset($result['total']) ? $result['total'] : 0;

// Sales total calculation
$result = mysqli_fetch_assoc(mysqli_query($conn, "
    SELECT SUM(s.quantity * p.selling_price) AS total
    FROM sales s
    JOIN products p ON s.product_id = p.id
"));
$sales_total = isset($result['total']) ? $result['total'] : 0;

// Highest Outbound Products
$highest_selling = mysqli_query($conn, "
    SELECT p.product AS name,
           SUM(s.quantity) AS sold,
           SUM(s.quantity * p.selling_price) AS total_price
    FROM sales s
    JOIN products p ON s.product_id = p.id
    GROUP BY s.product_id
    ORDER BY sold DESC
    LIMIT 5
");

// Latest Outbound
$latest_sales = mysqli_query($conn, "
    SELECT s.id, p.product AS name, s.sale_date, (s.quantity * p.selling_price) AS total
    FROM sales s
    JOIN products p ON s.product_id = p.id
    ORDER BY s.sale_date DESC
    LIMIT 5
");

// Recently Added Products
$recent_products = mysqli_query($conn, "
    SELECT product AS name, selling_price
    FROM products
    ORDER BY id DESC
    LIMIT 5
");
?> 

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard | Inventory System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <!-- Bootstrap CSS & FontAwesome -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

    <!-- Custom Dashboard CSS -->
    <link rel="stylesheet" href="./CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">
    <?php include 'sidebar.php'; ?>

    <!-- Page Content -->
    <div class="flex-grow-1 p-4" id="main-content">
        <div class="d-flex flex-column flex-md-row justify-content-between align-items-center mb-4">
            <h5 class="text-muted"><?php echo date('F j, Y, g:i a'); ?></h5>
            <div>
            <span class="alert alert-success py-1 px-3 m-0">Welcome, <?php echo $_SESSION['username']; ?></span>
                <a href="logout.php" class="btn btn-danger btn-sm ms-3"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>

        <!-- Summary Cards -->
        <div class="row text-center mb-4">
            <div class="col-sm-6 col-lg-3 mb-3">
                <div class="card">
                    <div class="card-body">
                        <h2><?php echo $users_count; ?></h2>
                        <p>Users</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mb-3">
                <div class="card bg-warning text-white">
                    <div class="card-body">
                        <h2><?php echo $categories_count; ?></h2>
                        <p>Categories</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mb-3">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <h2><?php echo $products_count; ?></h2>
                        <p>Products</p>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-lg-3 mb-3">


<div class="card bg-success text-white">
                    <div class="card-body">
                        <h2><?php echo number_format($sales_total, 2); ?> ETB</h2>
                        <p>Outbound Sales</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Tables Section -->
        <div class="row">
            <!-- Highest Outbound Products -->
            <div class="col-md-6 col-lg-4 mb-4">
                <h6>🏆 Top Outbound Products</h6>
                <div class="table-responsive table-wrapper">
                    <table class="table table-bordered table-striped mb-0">
                        <thead class="table-light sticky-top">
                            <tr><th>Title</th><th>Sold</th><th>Revenue</th></tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($highest_selling)) { ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['sold']; ?></td>
                                <td><?php echo number_format($row['total_price'],2); ?> ETB</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Latest Outbound -->
            <div class="col-md-6 col-lg-4 mb-4">
                <h6>🕒 Latest Outbound</h6>
                <div class="table-responsive table-wrapper">
                    <table class="table table-bordered table-striped mb-0">
                        <thead class="table-light sticky-top">
                            <tr><th>#</th><th>Product</th><th>Date</th><th>Total</th></tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($latest_sales)) { ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['sale_date']; ?></td>
                                <td><?php echo number_format($row['total'],2); ?> ETB</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Recently Added Products -->
            <div class="col-md-6 col-lg-4 mb-4">
                <h6>🆕 Recently Added Products</h6>
                <div class="table-responsive table-wrapper">
                    <table class="table table-bordered table-striped mb-0">
                        <thead class="table-light sticky-top">
                            <tr><th>Product</th><th>Price</th></tr>
                        </thead>
                        <tbody>
                            <?php while($row = mysqli_fetch_assoc($recent_products)) { ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo number_format($row['selling_price'],2); ?> ETB</td>
                            </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Bootstrap JS + Custom JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="./JS/dashboard-script.js"></script>
</body>
</html>