<?php
include 'connection.php';

// Validate ID
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage-users.php");
    exit();
}
$id = intval($_GET['id']);

// Fetch user
$sql = "SELECT * FROM userAdd WHERE id = $id";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0) {
    echo "User not found!";
    exit();
}
$user = mysqli_fetch_assoc($result);

// Handle update
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $role = mysqli_real_escape_string($conn, $_POST['role']);
    $status = mysqli_real_escape_string($conn, $_POST['status']);

    $update_sql = "UPDATE userAdd 
                   SET name = '$name', username = '$username', role = '$role', status = '$status' 
                   WHERE id = $id";

    if (mysqli_query($conn, $update_sql)) {
        header("Location: manage-users.php");
        exit();
    } else {
        echo "Error updating user: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit User - Inventory System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="./CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">
  <!-- Sidebar -->
  <nav class="sidebar text-white vh-100">
    <div class="sidebar-header text-dark bg-light p-3">
      <h5 class="mb-0 fw-bold">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
      <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
      <li class="nav-item"><a href="manage-users.php" class="nav-link text-white active"><i class="fas fa-user me-2"></i> User Management</a></li>
      <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
      <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
      <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
      <li class="nav-item"><a href="sales.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Sales</a></li>
      <li class="nav-item"><a href="sales-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Sales Report</a></li>
    </ul>
  </nav>

  <!-- Main Content -->
  <div class="p-4 flex-grow-1">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0 fw-bold">Edit User</h4>
      <a href="manage-users.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
    </div>

    <div class="card shadow-sm p-4">
      <form method="POST">
        <div class="mb-3">
          <label for="name" class="form-label">Full Name</label>
          <input type="text" class="form-control" id="name" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <input type="text" class="form-control" id="username" name="username" value="<?= htmlspecialchars($user['username']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="role" class="form-label">Role</label>
          <select class="form-select" id="role" name="role" required>
            <option value="Admin" <?= $user['role'] == 'Admin' ? 'selected' : '' ?>>Admin</option>
            <option value="Staff" <?= $user['role'] == 'Staff' ? 'selected' : '' ?>>Staff</option>
            <option value="Manager" <?= $user['role'] == 'Manager' ? 'selected' : '' ?>>Manager</option>
          </select>
        </div>
        <div class="mb-3">
          <label for="status" class="form-label">Status</label>
          <select class="form-select" id="status" name="status" required>
            <option value="Active" <?= $user['status'] == 'Active' ? 'selected' : '' ?>>Active</option>
            <option value="Inactive" <?= $user['status'] == 'Inactive' ? 'selected' : '' ?>>Inactive</option>
          </select>
        </div>
        <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Update User</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
