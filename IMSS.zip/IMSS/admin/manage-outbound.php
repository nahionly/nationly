<?php

include 'connection.php';
header("Cache-Control: no-cache, must-revalidate");

// --- Handle AJAX requests --- //
if(isset($_GET['action'])){
    $action = $_GET['action'];

    // ✅ Get sales
    if($action === 'getSales'){
        $res = mysqli_query($conn, "SELECT s.id, p.product, p.price, s.quantity, s.total, s.sale_date 
                                    FROM sales s 
                                    JOIN products p ON s.product_id = p.id 
                                    ORDER BY s.sale_date DESC");
        $sales = [];
        while($row = mysqli_fetch_assoc($res)){
            $sales[] = $row;
        }
        echo json_encode($sales);
        exit;
    }

    // ✅ Delete sale
    if($action === 'delete' && isset($_GET['id'])){
        $id = intval($_GET['id']);
        mysqli_query($conn, "DELETE FROM sales WHERE id=$id");
        echo "deleted";
        exit;
    }

    // ✅ Update sale
    if($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST'){
        $id = intval($_POST['id']);
        $quantity = intval($_POST['quantity']);

        $sale = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM sales WHERE id=$id"));
        if($sale){
            $product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE id=".$sale['product_id']));
            $total = $product['price'] * $quantity;
            mysqli_query($conn, "UPDATE sales SET quantity=$quantity, total=$total WHERE id=$id");
            echo "updated";
        } else {
            echo "error";
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Outbound Products | Inventory System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="./CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">

<!-- Sidebar -->
<nav class="sidebar text-white vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="mb-0 text-dark">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
<li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>        
        <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
        <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
        <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
        <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-whiteactive"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
        <li class="nav-item"><a href="outbound-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Outbound Report</a></li>
        <li class="nav-item"><a href="UserRequest.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Request</a></li>

    </ul>
</nav>

  <!-- Main Content -->
  <div class="p-4 flex-grow-1">
    <div class="btn btn-primary">
        <i class="fas "></i>Manage Outbound Products

    </div>

    <!-- Outbound Records Table -->
    <div>
        <table class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Product name</th>
                    <th>Quantity</th>
                    <th>Total</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody id="salesTable">
                <tr><td colspan="6" class="text-center">Loading...</td></tr>
            </tbody>
        </table>
    </div>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="editForm">
        <div class="modal-header">
          <h5 class="modal-title">Edit Outbound Product</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <input type="hidden" name="id" id="edit_id">
            <div class="mb-3">
                <label class="form-label">Quantity</label>
                <input type="number" name="quantity" id="edit_quantity" class="form-control" min="1" required>
            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script>
// ✅ Load sales
function loadSales(){
    fetch('manage-outbound.php?action=getSales')
        .then(res => res.json())
        .then(data => {
            const table = document.getElementById('salesTable');
            table.innerHTML = '';
            if(data.length === 0){
                table.innerHTML = '<tr><td colspan="6" class="text-center">No outbound records</td></tr>';
            } else {
                data.forEach((s, index) => {
                    table.innerHTML += `
                        <tr>
                            <td>${index+1}</td>
                            <td>${s.product}</td>
                            <td>${s.quantity}</td>
                            <td>${s.total}</td>
                            <td>${s.sale_date}</td>
                         
                        </tr>
                    `;
                });
            }
        });
}

// ✅ Delete sale
function deleteSale(id){
    if(confirm("Are you sure you want to delete this outbound record?")){
        fetch('manage-outbound.php?action=delete&id=' + id)
            .then(res => res.text())
            .then(data => {
                if(data.trim() === 'deleted'){
                    loadSales();
                }
            });
    }
}

// ✅ Edit sale (open modal)
function openEdit(id, qty){
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_quantity').value = qty;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

// ✅ Handle edit form
document.getElementById('editForm').addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(this);
    fetch('manage-outbound.php?action=update', { method: 'POST', body: formData })
        .then(res => res.text())
        .then(data => {
            if(data.trim() === 'updated'){
                loadSales();
                bootstrap.Modal.getInstance(document.getElementById('editModal')).hide();
            } else {
                alert('Error updating record.');
            }
        });
});

// Load sales on page start
loadSales();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
