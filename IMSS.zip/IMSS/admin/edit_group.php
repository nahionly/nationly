<?php
include 'connection.php';

// Get the ID from URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: manage-group.php");
    exit();
}
$id = intval($_GET['id']);

// Fetch group data
$sql = "SELECT * FROM groups WHERE id = $id";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) == 0) {
    echo "Group not found!";
    exit();
}
$group = mysqli_fetch_assoc($result);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $group_name = mysqli_real_escape_string($conn, $_POST['group_name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $update_sql = "UPDATE groups SET group_name = '$group_name', description = '$description' WHERE id = $id";

    if (mysqli_query($conn, $update_sql)) {
        header("Location: manage-group.php");
        exit();
    } else {
        echo "Error updating group: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Edit Group - Inventory System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="./CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">
  <!-- Sidebar -->
  <nav class="sidebar fw-bold text-dark vh-100">
    <div class="sidebar-header bg-light text-dark p-3">
      <h5 class="mb-0 fw-bold">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
      <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
      <li class="nav-item"><a href="manage-group.php" class="nav-link text-white active"><i class="fas fa-user me-2"></i> User Management</a></li>
      <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
      <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
      <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
      <li class="nav-item"><a href="sales.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Sales</a></li>
      <li class="nav-item"><a href="sales-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Sales Report</a></li>
    </ul>
  </nav>

  <!-- Main Content -->
  <div class="p-4 flex-grow-1">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0 fw-bold">Edit Group</h4>
      <a href="manage-group.php" class="btn btn-secondary"><i class="fas fa-arrow-left"></i> Back</a>
    </div>

    <div class="card shadow-sm p-4">
      <form method="POST">
        <div class="mb-3">
          <label for="group_name" class="form-label">Group Name</label>
          <input type="text" class="form-control" id="group_name" name="group_name" value="<?= htmlspecialchars($group['group_name']) ?>" required>
        </div>
        <div class="mb-3">
          <label for="description" class="form-label">Description</label>
          <textarea class="form-control" id="description" name="description" rows="3" required><?= htmlspecialchars($group['description']) ?></textarea>
        </div>
        <button type="submit" class="btn btn-success"><i class="fas fa-save"></i> Update Group</button>
      </form>
    </div>
  </div>
</div>

</body>
</html>
