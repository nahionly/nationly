
<?php
// connection.php

$servername = "localhost";
$username = "root"; // your DB username
$password = "";     // your DB password
$database = "inventory_system"; // replace with your DB name

// Create connection using mysqli
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
