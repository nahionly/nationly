<?php
session_start();
include 'connection.php';

// Handle delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);

    // Fetch the product image path first
    $sql = "SELECT image_path FROM products WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $product = $result->fetch_assoc();
    $stmt->close();

    if ($product) {
        // Delete the product
        $delete_sql = "DELETE FROM products WHERE id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            // Delete the image file if exists
            if ($product['image_path'] && file_exists($product['image_path'])) {
                unlink($product['image_path']);
            }
            $stmt->close();
            header("Location: products.php?msg=deleted");
            exit();
        } else {
            echo "Error deleting product: " . $stmt->error;
        }
    } else {
        header("Location: products.php");
        exit();
    }
}

// Fetch products with category
$sql = "
    SELECT 
        p.id,
        p.product AS product_title,
        COALESCE(c.name,'Uncategorized') AS category_name,
        p.quantity AS in_stock,
        p.buying_price,
        COALESCE(p.selling_price, p.price, 0) AS selling_price,
        p.created_at,
        p.image_path
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    ORDER BY p.created_at DESC, p.id DESC
";
$products = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Products | Inventory System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="./CSS/dashboard-style.css">
<style>
    .thumb { width: 48px; height: 48px; object-fit: cover; border-radius: 6px; }
    .table thead th { white-space: nowrap; }
</style>
</head>
<body>
<div class="d-flex">

<!-- Sidebar -->
<nav class="sidebar text-white vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="mb-0 text-dark">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
<li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>        
        <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
        <li class="nav-item"><a href="products.php" class="nav-link text-whiteactive"><i class="fas fa-box me-2"></i> Products</a></li>
        <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
        <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
        <li class="nav-item"><a href="outbound-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Outbound Report</a></li>
        <li class="nav-item"><a href="UserRequest.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Request</a></li>

    </ul>
</nav>

<!-- Main -->
<div class="p-4 flex-grow-1">
        <div class="btn btn-primary">
        <i class="fas "></i>product Search</h2>

        </div>

        <form method="POST" action="">
            <input type="text" name="search" placeholder="Enter product or model" required>
    <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <table class="table table-bordered table-hover mt-3">
            <thead class="table-dark">
                <tr>
                    <th class="text-center" style="width:60px;">#</th>
                    <th>Photo</th>
                    <th>Product Title</th>
                    <th>Categories</th>
                    <th class="text-end">In-Stock</th>
                    <th class="text-end">Buying Price</th>
                    <th class="text-end">Selling Price</th>
                    <th>Product Added</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $i = 1; 
                if ($products && mysqli_num_rows($products) > 0): 
                    while($row = mysqli_fetch_assoc($products)): 
                        $img = $row['image_path'] && file_exists($row['image_path']) ? $row['image_path'] : 'https://via.placeholder.com/48?text=%20';
                ?>
                <tr>
                    <td class="text-center"><?= $i++ ?></td>
                    <td><img src="<?= htmlspecialchars($img) ?>" class="thumb" alt="photo"></td>
                    <td><?= htmlspecialchars($row['product_title']) ?></td>
                    <td><?= htmlspecialchars($row['category_name']) ?></td>
                    <td class="text-end"><?= (int)$row['in_stock'] ?></td>
                    <td class="text-end"><?= number_format((float)$row['buying_price'], 2) ?></td>
                    <td class="text-end"><?= number_format((float)$row['selling_price'], 2) ?></td>
                    <td><?= date('F j, Y, g:i:s a', strtotime($row['created_at'])) ?></td>
                  
                </tr>
                <?php endwhile; else: ?>
                    <tr><td colspan="9" class="text-center">No products found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
