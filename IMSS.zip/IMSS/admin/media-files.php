<?php
session_start();
include 'connection.php';

$msg = '';

// Handle upload
if (isset($_POST['upload'])) {
    if (isset($_FILES['file']['name']) && $_FILES['file']['name'] != '') {
        $filename = $_FILES['file']['name'];
        $tmp = $_FILES['file']['tmp_name'];
        $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $allowed = ['jpg','jpeg','png','gif'];

        if (in_array($ext, $allowed)) {
            $newname = uniqid('img_') . '.' . $ext;

            // Store relative to web root
            $folder = "uploads/" . $newname;
            $fullPath = __DIR__ . "/" . $folder;

            if (move_uploaded_file($tmp, $fullPath)) {
                $stmt = $conn->prepare("INSERT INTO media_files (file_name, file_path, uploaded_on) VALUES (?, ?, NOW())");
                $stmt->bind_param("ss", $filename, $folder); // store path as 'uploads/img_xyz.jpg'
                $stmt->execute();
                $stmt->close();
                $msg = "Upload successful!";
            } else {
                $msg = "Failed to upload file.";
            }
        } else {
            $msg = "Only image files allowed.";
        }
    } else {
        $msg = "Please select a file.";
    }
}

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $q = $conn->prepare("SELECT file_path FROM media_files WHERE id=?");
    $q->bind_param("i", $id);
    $q->execute();
    $res = $q->get_result();
    if ($row = $res->fetch_assoc()) {
        $path = __DIR__ . "/" . $row['file_path'];
        if (is_file($path)) unlink($path);
    }
    $q->close();

    $d = $conn->prepare("DELETE FROM media_files WHERE id=?");
    $d->bind_param("i", $id);
    $d->execute();
    $d->close();

    header("Location: media-files.php?msg=deleted");
    exit;
}

// Fetch all media
$media = $conn->query("SELECT * FROM media_files ORDER BY uploaded_on DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Media Files | Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="./CSS/dashboard-style.css">
<style>
    .thumb { width: 48px; height: 48px; object-fit: cover; border-radius: 6px; }
    .table thead th { white-space: nowrap; }
</style>
</head>
<body>
<div class="d-flex">

<!-- Sidebar -->
<nav class="sidebar text-white vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="mb-0 text-dark">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
<li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>        
        <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
        <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
        <li class="nav-item"><a href="media-files.php" class="nav-link text-whiteactive"><i class="fas fa-image me-2"></i> Media Files</a></li>
        <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
        <li class="nav-item"><a href="outbound-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Outbound Report</a></li>
        <li class="nav-item"><a href="UserRequest.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Request</a></li>

    </ul>
</nav>

<div class="container">
     <div class="btn btn-primary">
        <i class="fas "></i>media-files
    </div>
    <hr>
    <table class="table table-bordered">
        <tr>
            <th>#</th>
            <th>Preview</th>
            <th>Name</th>
            <th>Actions</th>
        </tr>
        <?php $i = 1; while($m = $media->fetch_assoc()): ?>
        <tr>
            <td><?= $i++ ?></td>
            <td><img src="<?= htmlspecialchars($m['file_path']) ?>" class="thumb"></td>
            <td><?= htmlspecialchars($m['file_name']) ?></td>
            <td>
                <a href="<?= htmlspecialchars($m['file_path']) ?>" target="_blank" class="btn btn-info btn-sm">View</a>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>
</div>
</body>
</html>
