<?php
include 'connection.php';

$id = intval($_GET['id']);
$result = mysqli_query($conn, "SELECT * FROM products WHERE id = $id");
$product_data = mysqli_fetch_assoc($result);

if (!$product_data) {
    die("Product not found.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product = mysqli_real_escape_string($conn, $_POST['product']);
    $model = mysqli_real_escape_string($conn, $_POST['model']);
    $quantity = intval($_POST['quantity']);

    $update_sql = "UPDATE products SET product = '$product', model = '$model', quantity = $quantity WHERE id = $id";
    if (mysqli_query($conn, $update_sql)) {
        header("Location: products.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
<div class="container">
    <h2>Edit Product</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Product</label>
            <input type="text" name="product" value="<?= htmlspecialchars($product_data['product']) ?>" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Model</label>
            <input type="text" name="model" value="<?= htmlspecialchars($product_data['model']) ?>" class="form-control">
        </div>
        <div class="mb-3">
            <label>Quantity</label>
            <input type="number" name="quantity" value="<?= htmlspecialchars($product_data['quantity']) ?>" class="form-control" min="0" required>
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="products.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>
</body>
</html>
