<?php
include('connection.php');

$fname =$_POST['fname'];
$lname =$_POST['lname'];
$office =$_POST['office'];
$password =$_POST['password'];
$email =$_POST['email'];

 
 

$save=mysql_query("INSERT INTO registrations(fname, lname, office, password,email, date)
  VALUES ('$fname','$lname','$office','$password','$email',now())");
  if(!$save)
  {
    die(mysql_error());
    }
  echo"<script>alert('Thanks! You have registered successfully! ')</script>";
  echo"<script>window.open('login.html','_self')</script>";
  exit();
?>