<?php
include 'connection.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Get file name from DB
    $res = mysqli_query($conn, "SELECT file_name FROM media_files WHERE id=$id LIMIT 1");
    $file = mysqli_fetch_assoc($res);

    if ($file) {
        $filePath = "uploads/" . $file['file_name'];
        if (file_exists($filePath)) {
            unlink($filePath); // delete file from server
        }
        mysqli_query($conn, "DELETE FROM media_files WHERE id=$id");
    }
}

header("Location: media_files.php");
exit();
?>
