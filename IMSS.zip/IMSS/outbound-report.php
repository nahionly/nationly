<?php
session_start();

include 'connection.php';

// Fetch report data dynamically
$sql = "SELECT s.sale_date, p.product, p.buying_price, p.price AS selling_price, 
               s.quantity, (s.quantity * p.price) AS total
        FROM sales s
        JOIN products p ON s.product_id = p.id
        ORDER BY s.sale_date DESC";
$result = mysqli_query($conn, $sql);

$rows = [];
$grand_total = 0;
$total_profit = 0;

if ($result && mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)){
        $profit = ($row['selling_price'] - $row['buying_price']) * $row['quantity'];
        $row['profit'] = $profit;
        $rows[] = $row;
        $grand_total += $row['total'];
        $total_profit += $profit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Outbound Report | Inventory System</title>

      <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="./CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">

<!-- Sidebar -->
<nav class="sidebar text-white vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="mb-0 text-dark">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
<li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>        
        <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
        <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
        <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
        <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
        <li class="nav-item"><a href="outbound-report.php" class="nav-link text-whiteactive"><i class="fas fa-file-alt me-2"></i> Outbound Report</a></li>
        <li class="nav-item"><a href="./User/UserRequest.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Request</a></li>

    </ul>
</nav>
<div class="container">
    <h3 class="text-center">Inventory Management System - Outbound Report</h3>

    <table class="table table-bordered table-striped">
        <thead class="table-dark">
            <tr>
                <th>Date</th>
                <th>Product Title</th>
                <th>Buying Price</th>
                <th>Selling Price</th>
                <th>Total Qty</th>
                <th>TOTAL</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($rows) > 0): ?>
                <?php foreach($rows as $r): ?>
                <tr>
                    <td><?= htmlspecialchars($r['sale_date']) ?></td>
                    <td><?= htmlspecialchars($r['product']) ?></td>
                    <td>$<?= number_format($r['buying_price'], 2) ?></td>
                    <td>$<?= number_format($r['selling_price'], 2) ?></td>
                    <td><?= $r['quantity'] ?></td>
                    <td>$<?= number_format($r['total'], 2) ?></td>
                </tr>
                <?php endforeach; ?>
                <!-- Grand Total -->
                <tr class="report-footer">
                    <td colspan="5" class="text-end">GRAND TOTAL</td>
                    <td>$<?= number_format($grand_total, 2) ?></td>
                </tr>
                <!-- Profit -->
                <tr class="report-footer">
                    <td colspan="5" class="text-end">PROFIT</td>
                    <td>$<?= number_format($total_profit, 2) ?></td>
                </tr>
            <?php else: ?>
                <tr><td colspan="6" class="text-center">No outbound records found</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
