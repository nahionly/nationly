<?php
include 'connection.php';

// Handle delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $delete_sql = "DELETE FROM categories WHERE id = $id";
    if (mysqli_query($conn, $delete_sql)) {
        header("Location: categories.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

// Fetch categories
$result = mysqli_query($conn, "SELECT * FROM categories");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Inventory System - Categories</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <!-- Custom CSS -->
  <link rel="stylesheet" href="./CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">

<!-- Sidebar -->
<nav class="sidebar text-white vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="mb-0 text-dark">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
<li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>    
        <li class="nav-item"><a href="categories.php" class="nav-link text-whiteactive"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
        <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
        <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
        <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-white"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
        <li class="nav-item"><a href="outbound-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Outbound Report</a></li>
        <li class="nav-item"><a href="./User/UserRequest.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Request</a></li>

    </ul>
</nav>

  <!-- Main Content -->
  <div class="p-4 flex-grow-1">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0">CATEGORIES</h4>
      <a href="add_category.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Add New Category
      </a>
    </div>

    <table class="table table-bordered table-hover">
      <thead class="table-dark">
        <tr>
          <th>#</th>
          <th>Category Name</th>
          <th>Description</th>
          <th>Actions</th>
        </tr>
      </thead>
     <tbody>
  <?php 
  $counter = 1; // Start numbering from 1
  while ($row = mysqli_fetch_assoc($result)) : ?>
    <tr>
      <td><?= $counter++ ?></td> <!-- Auto increment instead of DB id -->
      <td><?= htmlspecialchars($row['name']) ?></td>
      <td><?= htmlspecialchars($row['description']) ?></td>
      <td>
        <a href="edit_category.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">
          <i class="fas fa-pen"></i>
        </a>
        <a href="categories.php?delete=<?= $row['id'] ?>" 
           onclick="return confirm('Are you sure you want to delete this category?')" 
           class="btn btn-danger btn-sm">
          <i class="fas fa-times"></i>
        </a>
      </td>
    </tr>
  <?php endwhile; ?>
</tbody>

    </table>
  </div>
</div>

</body>
</html>
