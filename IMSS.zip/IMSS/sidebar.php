<!-- Sidebar -->
<nav class="sidebar text-dark fw-bold vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="fw-bold mb-0">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">

        <li class="nav-item">
            <a href="./dashboard.php" class="nav-link text-white">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
        </li>
        
        <!-- User Management -->
        <li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>

        <li class="nav-item">
            <a href="categories.php" class="nav-link text-white">
                <i class="fas fa-layer-group me-2"></i> Categories
            </a>
        </li>

        <li class="nav-item">
            <a href="products.php" class="nav-link text-white">
                <i class="fas fa-box me-2"></i> Products
            </a>
        </li>

        <li class="nav-item">
            <a href="media-files.php" class="nav-link text-white">
                <i class="fas fa-image me-2"></i> Media Files
            </a>
        </li>

        <!-- Outbound Products with Submenu -->
        <li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#outboundMenu" role="button" aria-expanded="false" aria-controls="outboundMenu">
                <i class="fas fa-truck me-2"></i> Outbound Products
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="outboundMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-white">Manage Outbound Products</a></li>
                    <li class="nav-item"><a href="add-outbound.php" class="nav-link text-white">Add Outbound Products</a></li>
                </ul>
            </div>
        </li>

        <li class="nav-item">
            <a href="outbound-report.php" class="nav-link text-white">
                <i class="fas fa-file-alt me-2"></i> Outbound Report
            </a>
        </li>
<li class="nav-item">
            <a href="./User/UserRequest.php" class="nav-link text-white">
                <i class="fas fa-file-alt me-2"></i> Request
            </a>
        </li>
    </ul>
</nav>
