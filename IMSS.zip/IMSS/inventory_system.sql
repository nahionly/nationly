-- phpMyAdmin SQL Dump
-- version 4.0.4
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Sep 27, 2025 at 08:25 PM
-- Server version: 5.6.12-log
-- PHP Version: 5.4.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `inventory_system`
--
CREATE DATABASE IF NOT EXISTS `inventory_system` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `inventory_system`;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`) VALUES
(4, 'Iphone Mobile', 'good and perfect product\r\n'),
(6, 'Mobile', 'GSJHSGHJ'),
(9, 'Mobile2', 'www'),
(10, 'Desktop', 'This desktops are for Adama Administration office '),
(11, 'laptop', 'no'),
(12, 'bright', 'abi office');

-- --------------------------------------------------------

--
-- Table structure for table `fedback`
--

CREATE TABLE IF NOT EXISTS `fedback` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fedback` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `fedback`
--

INSERT INTO `fedback` (`id`, `fedback`, `date`) VALUES
(1, 'fvhcgmajh', '2025-08-14 20:23:46');

-- --------------------------------------------------------

--
-- Table structure for table `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `username` varchar(45) NOT NULL,
  `password` varchar(56) NOT NULL,
  `description` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `groups`
--

INSERT INTO `groups` (`id`, `group_name`, `username`, `password`, `description`) VALUES
(9, 'IT', '', '', 'gaKJX'),
(11, 'IS', '', '', '54TRDYFUGH6RTU'),
(12, 'A', 'HENI', '1234', 'ACOUNTING');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`) VALUES
(7, 'Nati', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `media_files`
--

CREATE TABLE IF NOT EXISTS `media_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `uploaded_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `media_files`
--

INSERT INTO `media_files` (`id`, `file_name`, `file_path`, `product_id`, `uploaded_on`) VALUES
(18, 'FINAL.png', 'uploads/img_68b34059e955d.png', NULL, '2025-08-30 15:18:01'),
(19, 'code .png', 'uploads/img_627e14d720eb5.png', NULL, '2022-05-13 05:20:39');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product` varchar(100) DEFAULT NULL,
  `model` varchar(50) NOT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT '0.00',
  `category_id` int(11) DEFAULT NULL,
  `buying_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `selling_price` decimal(10,2) NOT NULL DEFAULT '0.00',
  `image_path` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `stock` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product`, `model`, `quantity`, `price`, `category_id`, `buying_price`, `selling_price`, `image_path`, `created_at`, `stock`) VALUES
(15, 'red', '', 12, '0.00', 4, '2000.00', '4000.00', 'uploads/1756322973_photo_2025-05-19_22-04-42.jpg', '2025-08-27 12:29:34', 0),
(17, 'cher', '', 100, '0.00', 11, '210.00', '220.00', 'uploads/1756577947_FINAL.png', '2025-08-30 15:19:07', 0),
(18, 'food', '', 400, '0.00', 10, '100.00', '120.00', 'uploads/1652431284_download (1).png', '2022-05-13 05:41:24', 0),
(19, 'printer', '', 23, '0.00', 12, '150.00', '200.00', NULL, '2022-05-08 07:37:57', 0),
(20, 'soft', '', 121, '0.00', 12, '67.00', '70.00', NULL, '2022-05-17 01:04:13', 0),
(21, 'soft', '', 121, '0.00', 12, '67.00', '70.00', NULL, '2022-05-17 01:04:13', 0),
(22, 'soft', '', 121, '0.00', 12, '55.00', '60.00', NULL, '2022-05-17 01:04:51', 0),
(23, 'pixel', '', 323, '0.00', 4, '300.00', '350.00', 'uploads/1652760957_20240105_111523.jpg', '2022-05-17 01:15:57', 0);

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE IF NOT EXISTS `requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `request_purpose` text NOT NULL,
  `requested_by` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `office_name` varchar(100) DEFAULT NULL,
  `request_date` date DEFAULT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `product_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `product_name`, `quantity`, `request_purpose`, `requested_by`, `email`, `office_name`, `request_date`, `status`, `date`, `product_id`) VALUES
(1, 'Table', 10, 'ypihhwdjh', 'dqfwgjkf', 'ddd@gmail.com', 'er', '0000-00-00', 'approved', '2025-08-26 11:04:06', 0),
(2, 'Table', 12, 'fg', 'dr', 'sirajdalu@gmail.com', 'ur', '0000-00-00', 'rejected', '2025-08-26 11:04:30', 0),
(3, 'gkafvj', 6, 'wJHF', 'dqfwgjkf', 'hwhhw@gg', 'YYUK', '0000-00-00', 'approved', '2025-08-26 11:57:10', 0),
(4, '', 2, 'ghh', 'dr', 'hwhhw@gg', 'fy', '0000-00-00', 'rejected', '2025-08-26 14:14:32', 3),
(5, '', 12, 'ass', 'gjkgj', 'mam@gmail.com', 'GD', '0000-00-00', 'pending', '2025-08-27 08:41:24', 9),
(6, '', 12, 'gh', 'mee', 'siraj@gmail.com', 'you', '0000-00-00', 'pending', '2025-08-27 20:13:55', 4),
(7, '', 12, 'axsx', 'nati', 'nahi6@gmail.comb', 'adama', '2025-08-30', 'approved', '2025-08-30 18:55:24', 15),
(8, '', 45, 'jxk x x ', 'natan', 'nati6565@gmail.comb', 'smart', '0000-00-00', 'rejected', '2022-05-13 08:31:28', 15),
(9, '', 2, 'dfdfgdrx\\sdsdscxdw wxdcd', 'natan', 'nahi6@gmail.comb', 'bright', '2022-05-10', 'rejected', '2022-05-08 10:43:07', 19);

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `sale_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=21 ;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`id`, `product_id`, `quantity`, `total`, `sale_date`) VALUES
(1, 3, 2, '0.00', '2025-08-21 18:03:44'),
(2, 4, 2, '0.00', '2025-08-21 18:21:48'),
(3, 7, 100, '0.00', '2025-08-21 18:22:22'),
(4, 9, 12, '0.00', '2025-08-21 18:25:48'),
(6, 6, 5, '5000.00', '2025-08-21 18:35:05'),
(9, 9, 78, '0.00', '2025-08-21 19:59:47'),
(10, 9, 4, '0.00', '2025-08-27 17:46:08'),
(11, 9, 10, '0.00', '2025-08-27 17:46:55'),
(12, 9, 12, '0.00', '2025-08-28 04:49:14'),
(13, 9, 5, '0.00', '2025-08-28 05:18:43'),
(14, 6, 4, '4000.00', '2025-08-28 05:19:08'),
(15, 17, 23, '0.00', '2022-05-13 10:08:57'),
(16, 17, 2, '0.00', '2022-05-13 10:09:06'),
(17, 17, 50, '0.00', '2022-05-13 11:37:23'),
(18, 15, 3, '0.00', '2022-05-13 11:39:08'),
(19, 18, 100, '0.00', '2022-05-13 11:42:14'),
(20, 19, 10, '0.00', '2022-05-08 13:38:56');

-- --------------------------------------------------------

--
-- Table structure for table `useradd`
--

CREATE TABLE IF NOT EXISTS `useradd` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('Admin','User','Special') DEFAULT 'User',
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `last_login` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `useradd`
--

INSERT INTO `useradd` (`id`, `name`, `username`, `password`, `role`, `status`, `last_login`, `created_at`, `updated_at`) VALUES
(8, 'Nati', 'Nati', '$2y$10$tn6K/DieFAZoeCJH0fR/euO82XPQzJaI9i9W17Ftoficzijt0Tx3a', 'User', 'Active', NULL, '2025-08-21 00:16:49', '2025-08-21 00:16:49'),
(11, 'nati', 'nahi', '1212', 'Admin', 'Active', NULL, '2025-08-30 15:43:12', '2025-08-30 16:46:47'),
(12, 'beki', 'beku', '', 'Special', 'Active', NULL, '2025-08-30 15:43:52', '2025-08-30 15:43:52'),
(13, 'ebisa', 'ebisa', '', 'User', 'Active', NULL, '2025-08-30 15:48:12', '2025-08-30 15:48:12'),
(16, 'tolosa', 'tolosa', '', 'User', 'Active', NULL, '2022-05-13 05:56:32', '2022-05-13 05:56:32'),
(17, 'duni', 'duni', '', 'User', 'Active', NULL, '2022-05-17 00:50:57', '2022-05-17 00:50:57'),
(21, 'natiaa', 'bitilex', '090934', 'Admin', 'Active', NULL, '2022-05-17 02:04:46', '2022-05-17 02:04:46'),
(22, 'bi', 'bitile', '0909', 'User', 'Active', NULL, '2022-05-17 02:05:35', '2022-05-17 02:05:35');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
