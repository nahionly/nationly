// Example future dashboard JS
document.addEventListener("DOMContentLoaded", function() {
    console.log("Dashboard loaded successfully!");
});
