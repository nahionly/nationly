<?php
include('connection.php');

$fedback =$_POST['fedback'];

 
 

$save=mysql_query("INSERT INTO fedback(fedback,  date)
  VALUES ('$fedback',now())");
  if(!$save)
  {
    die(mysql_error());
    }
  echo"<script>alert('Thanks! You have registered successfully! ')</script>";
  echo"<script>window.open('fedback.html','_self')</script>";
  exit();
?>