<?php
include "connection.php";

if(isset($_POST['product_id'], $_POST['quantity'])){
    $product_id = intval($_POST['product_id']);
    $quantity   = intval($_POST['quantity']);
    $date       = date("Y-m-d H:i:s");

    $product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE id=$product_id"));
    if($product && $quantity > 0){
        $price = $product['price'];
        $total = $price * $quantity;

        mysqli_query($conn, "INSERT INTO outbound (product_id, price, qty, total, outbound_date) 
                             VALUES ($product_id, $price, $quantity, $total, '$date')");
        echo "success";
    } else {
        echo "error";
    }
}
?>
