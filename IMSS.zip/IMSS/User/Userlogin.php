<?php
session_start();
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);

    // Fetch user
    $sql = "SELECT * FROM userAdd WHERE username = '$username' LIMIT 1";
    $result = mysqli_query($conn, $sql);

    if ($row = mysqli_fetch_assoc($result)) {
        // Check plain password (better: use password_hash in future)
        if ($password === $row['password']) {
            // Save session
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['username'] = $row['username'];
            $_SESSION['role'] = $row['role'];

            // Redirect to dashboard
            header("Location: userdashboard.php");
            exit();
        } else {
            $error = "Invalid password.";
        }
    } else {
        $error = "User not found.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Login | Inventory System</title>
  <link rel="stylesheet" href="../CSS/bootstrap.min.css">
  <link rel="stylesheet" href="../CSS/style.css">
</head>
<body>

<div class="login-box">
    <div>
        <a href="../index.php">
          <img class="logo-img" src="../Resources/image.png" alt="logo">
        </a>
    </div>
    <h2>Login</h2>
    <h3>Inventory Management System</h3>

    <?php if (!empty($error)): ?>
      <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form action="Userlogin.php" method="post">
        <input type="text" name="username" class="form-control" placeholder="Username" required />
        <input type="password" name="password" class="form-control" placeholder="Password" required />
        <input type="submit" value="Login" class="btn btn-primary w-100 mt-2">
    </form>
    <p class="mt-2">Don’t have permission? <a href="../index.php">Back to Home</a></p>
</div>

<script src="../User/JS/userdashboard-script.js"></script>
</body>
</html>
