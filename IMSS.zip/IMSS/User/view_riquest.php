<?php
$servername = "localhost";
$username = "root";   // change if needed
$password = "";       // change if needed
$dbname = "ims";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Filter by status if requested
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

$sql = "SELECT * FROM riquests";
if ($status_filter != '') {
    $sql .= " WHERE status='$status_filter'";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Leaves</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        table { border-collapse: collapse; width: 100%; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: center; }
        th { background: #f2f2f2; }
        button { padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer; }
        .filter-btn { background: teal; color: white; margin: 5px; }
        .view-btn { background: #00b894; color: white; }
    </style>
</head>
<body>

<h2>Manage Leaves</h2>

<form method="get">
    <button type="submit" name="status" value="Pending" class="filter-btn">Pending</button>
    <button type="submit" name="status" value="Approved" class="filter-btn">Approved</button>
    <button type="submit" name="status" value="Rejected" class="filter-btn">Rejected</button>
</form>

<table>
    <tr>
        <th>S No</th>
        <th>Emp ID</th>
        <th>Name</th>
        <th>Leave Type</th>
        <th>Department</th>
        <th>Days</th>
        <th>Status</th>
        <th>Action</th>
    </tr>

    <?php
    $sno = 1;
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            echo "<tr>
                <td>".$sno++."</td>
                <td>".$row['emp_id']."</td>
                <td>".$row['name']."</td>
                <td>".$row['leave_type']."</td>
                <td>".$row['department']."</td>
                <td>".$row['days']."</td>
                <td>".$row['status']."</td>
                <td><a href='leave_details.php?id=".$row['id']."'><button class='view-btn'>View</button></a></td>
            </tr>";
        }
    } else {
        echo "<tr><td colspan='8'>No records found</td></tr>";
    }
    ?>
</table>

</body>
</html>
