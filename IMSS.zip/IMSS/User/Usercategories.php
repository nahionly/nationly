<?php
include 'connection.php';

// Handle delete request
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $delete_sql = "DELETE FROM categories WHERE id = $id";
    if (mysqli_query($conn, $delete_sql)) {
        header("Location: categories.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

// Default query
$sql = "SELECT * FROM categories";

// If searching
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['search'])) {
    $search = "%" . $_POST['search'] . "%";
    $stmt = $conn->prepare("SELECT * FROM categories WHERE name LIKE ? OR description LIKE ?");
    $stmt->bind_param("ss", $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $result = mysqli_query($conn, $sql);
}

if (!$result) {
    die("Query Failed: " . mysqli_error($conn));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Inventory System - Categories</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link rel="stylesheet" href="../CSS/dashboard-style.css">
</head>
<body>

<div class="d-flex">
   <?php include './sidebar.php'; ?>

  </nav>

  <!-- Main Content -->
  <div class="p-4 flex-grow-1">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h4 class="mb-0">CATEGORIES</h4>
    </div>
    <form method="POST" action="">
    <input type="text" name="search" placeholder="categories and Description" required>
    <button type="submit" class="btn btn-primary">Search</button>
</form>

<table class="table table-bordered table-hover mt-3">
    <thead class="table-dark">
        <tr>
            <th>#</th> <!-- Sequential numbering -->
            <th>Category Name</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        if ($result && mysqli_num_rows($result) > 0) {
            $rowNumber = 1; // start numbering from 1
            while ($row = mysqli_fetch_assoc($result)) : ?>
                <tr>
                    <td><?= $rowNumber ?></td>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= htmlspecialchars($row['description']) ?></td>
                  
                </tr>
            <?php 
                $rowNumber++; 
            endwhile; 
        } else {
            echo "<tr><td colspan='4' class='text-center'>No categories found.</td></tr>";
        }
        ?>
      </tbody>
    </table>
  </div>
</div>

</body>
</html>
