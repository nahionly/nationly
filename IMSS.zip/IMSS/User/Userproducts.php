<?php
include 'connection.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $delete_sql = "DELETE FROM products WHERE id = $id";
    if (mysqli_query($conn, $delete_sql)) {
        header("Location: products.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($conn);
    }
}

// Handle search
$searchTerm = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['search'])) {
    $search = $_POST['search'];
    $sql = "SELECT * FROM products WHERE product LIKE ? OR model LIKE ?";
    $stmt = $conn->prepare($sql);
    $searchTerm = "%" . $search . "%";
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
} else {
    // Default: fetch all products
    $result = mysqli_query($conn, "SELECT * FROM products");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - Products</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../CSS/dashboard-style.css">
</head>
<body>
<div class="d-flex">
     <?php include './sidebar.php'; ?>

    <!-- Main Content -->
    <div class="p-4 flex-grow-1">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2 class="mb-0">product Search</h2>

        </div>

        <form method="POST" action="">
            <input type="text" name="search" placeholder="Enter product or model" required>
    <button type="submit" class="btn btn-primary">Search</button>
        </form>

        <table class="table table-bordered table-hover mt-3">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Product</th>
                    <th>Model</th>
                    <th>Quantity</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                if ($result && mysqli_num_rows($result) > 0) {
                    $rowNumber = 1;
                    while ($row = mysqli_fetch_assoc($result)) : ?>
                        <tr>
                            <td><?= $rowNumber ?></td>
                            <td><?= htmlspecialchars($row['product']) ?></td>
                            <td><?= htmlspecialchars($row['model']) ?></td>
                            <td><?= htmlspecialchars($row['quantity']) ?></td>
                        </tr>
                    <?php 
                        $rowNumber++;
                    endwhile; 
                } else {
                    echo "<tr><td colspan='4' class='text-center'>No products found.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>
</body>
</html>
