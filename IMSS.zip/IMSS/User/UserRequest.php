<?php
session_start();
include '../connection.php';

// Filter by status
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Build query
if ($status_filter && in_array($status_filter, ['Pending','Approved','Rejected'])) {
    $sql = "SELECT * FROM requests WHERE status='$status_filter' ORDER BY request_date DESC";
} else {
    $sql = "SELECT * FROM requests ORDER BY request_date DESC";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2>User Requests</h2>

    <!-- Filter Buttons -->
    <form method="get" class="mb-3">
        <button type="submit" name="status" value="Pending" class="btn btn-warning">Pending</button>
        <button type="submit" name="status" value="Approved" class="btn btn-success">Approved</button>
        <button type="submit" name="status" value="Rejected" class="btn btn-danger">Rejected</button>
        <a href="UserRequest.php" class="btn btn-secondary">All</a>
        <a href="http://localhost/imss/dashboard.php" class="btn btn-primary">
        <i class="fas"></i> Back
      </a>
    </form>

    <table class="table table-bordered table-hover text-center">
        <thead class="table-dark">
            <tr>
                <th>ID</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Purpose</th>
                <th>Requested By</th>
                <th>Email</th>
                <th>Office</th>
                <th>Request Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php
        if ($result && $result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $status = strtolower($row['status']); // make case-insensitive

                // Determine badge
                if ($status == 'pending') {
                    $badge = "<span class='badge bg-warning text-dark'>Pending</span>";
                } elseif ($status == 'approved') {
                    $badge = "<span class='badge bg-success'>Approved</span>";
                } elseif ($status == 'rejected') {
                    $badge = "<span class='badge bg-danger'>Rejected</span>";
                } else {
                    $badge = "<span class='badge bg-secondary'>Unknown</span>";
                }

                echo "<tr>
                    <td>{$row['id']}</td>
                    <td>".htmlspecialchars($row['product_name'])."</td>
                    <td>".htmlspecialchars($row['quantity'])."</td>
                    <td>".htmlspecialchars($row['request_purpose'])."</td>
                    <td>".htmlspecialchars($row['requested_by'])."</td>
                    <td>".htmlspecialchars($row['email'])."</td>
                    <td>".htmlspecialchars($row['office_name'])."</td>
                    <td>".htmlspecialchars($row['request_date'])."</td>
                    <td>$badge</td>
                    <td>
                        <a href='leave_details.php?id={$row['id']}' class='btn btn-info btn-sm'>View</a>
                    </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='10'>No requests found</td></tr>";
        }
        ?>
        </tbody>
    </table>
</div>

</body>
</html>
