<?php
session_start();
include '../connection.php'; // Adjust path to connection.php

// Fetch all media
$media = $conn->query("SELECT * FROM media_files ORDER BY uploaded_on DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inventory System - User Media</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../CSS/dashboard-style.css">

<style>
.thumb { width: 80px; height: 80px; object-fit: cover; border-radius: 6px; }
</style>
</head>
<body class="p-4">
 <div class="d-flex">
     <?php include './sidebar.php'; ?>

<div class="container">
   

    <h2>Available Media</h2>

    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <tr>
                <th>#</th>
                <th>Preview</th>
                <th>Name</th>
                <th>Type</th>
                <th>Action</th>
            </tr>

            <?php
            if ($media && $media->num_rows > 0):
                $i = 1;
                while ($m = $media->fetch_assoc()):
                    $ext = strtoupper(pathinfo($m['file_path'], PATHINFO_EXTENSION));
            ?>
            <tr>
                <td><?= $i++ ?></td>
                <td><img src="../<?= htmlspecialchars($m['file_path']) ?>" class="thumb"></td>
                <td><?= htmlspecialchars($m['file_name']) ?></td>
                <td><?= $ext ?></td>
                <td><a href="../<?= htmlspecialchars($m['file_path']) ?>" target="_blank" class="btn btn-info btn-sm">View</a></td>
            </tr>
            <?php endwhile; else: ?>
            <tr><td colspan="5" class="text-center">No media found.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</div>
</div>
</body>
</html>
