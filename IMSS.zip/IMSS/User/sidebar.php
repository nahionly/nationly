<?php
// Get current page name, ignoring #hash or ?query string
$current_page = basename(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH));
?>

<nav class="sidebar text-dark fw-bold vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="fw-bold mb-0">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item">
            <a href="./Userdashboard.php" class="nav-link text-white <?php echo ($current_page == 'Userdashboard.php') ? 'active' : ''; ?>">
                <i class="fas fa-home me-2"></i> Dashboard
            </a>
        </li>
        
       

        <li class="nav-item">
            <a href="Usercategories.php" class="nav-link text-white <?php echo ($current_page == '  Usercategories.php') ? 'active' : ''; ?>">
                <i class="fas fa-layer-group me-2"></i> Categories
            </a>
        </li>
        <li class="nav-item">
            <a href="Userproducts.php" class="nav-link text-white <?php echo ($current_page == 'Userproducts.php') ? 'active' : ''; ?>">
                <i class="fas fa-box me-2"></i> Products
            </a>
        </li>
        <li class="nav-item">
            <a href="Usermedia.php" class="nav-link text-white <?php echo ($current_page == 'Usermedia.php') ? 'active' : ''; ?>">
                <i class="fas fa-image me-2"></i> Media Files
            </a>
        </li>

        

        <li class="nav-item">
            <a href="riquest.php" class="nav-link text-white <?php echo ($current_page == 'riquest.php') ? 'active' : ''; ?>">
                <i class="fas fa-file-alt me-2"></i> Request
            </a>
        </li>
    </ul>
</nav>
