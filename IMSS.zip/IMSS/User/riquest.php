<?php
include('connection.php');

$message = '';

// Fetch products from the database
$products = [];
$product_sql = "SELECT id, product FROM products ORDER BY product ASC";
$product_result = $conn->query($product_sql);
if ($product_result->num_rows > 0) {
    while ($row = $product_result->fetch_assoc()) {
        $products[] = $row;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {

    $product_id      = isset($_POST['product_id']) ? $_POST['product_id'] : 0;
    $quantity        = isset($_POST['quantity']) ? $_POST['quantity'] : 0;
    $request_purpose = isset($_POST['request_purpose']) ? $_POST['request_purpose'] : '';
    $requested_by    = isset($_POST['requested_by']) ? $_POST['requested_by'] : '';
    $email           = isset($_POST['email']) ? $_POST['email'] : '';
    $office_name     = isset($_POST['office_name']) ? $_POST['office_name'] : '';
    $request_date    = isset($_POST['request_date']) ? $_POST['request_date'] : date('Y-m-d');

    // Insert into requests table using product_id
    $sql = "INSERT INTO requests (product_id, quantity, request_purpose, requested_by, email, office_name, request_date, status, date)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'Pending', NOW())";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iisssss", $product_id, $quantity, $request_purpose, $requested_by, $email, $office_name, $request_date);

    if ($stmt->execute()) {
        $message = "✅ Your request has been submitted successfully!";
    } else {
        $message = "❌ Error: " . $stmt->error;
    }

    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Submit Request | Inventory System</title>
    <link rel="stylesheet" href="../CSS/bootstrap.min.css">
</head>
<body class="p-4">

<div class="container" style="max-width: 600px;">
    <h2> <a href="userdashboard.php" class="btn btn-primary">
        <i class="fas"></i> Back
      </a>Submit a Product Request</h2>

    <?php if (!empty($message)): ?>
        <div class="alert alert-info"><?= htmlspecialchars($message) ?></div>
    <?php endif; ?>

    <form action="" method="post">
        <div class="mb-3">
            <label for="product_id" class="form-label">Product</label>
            <select name="product_id" id="product_id" class="form-control" required>
                <option value="">-- Select Product --</option>
                <?php foreach ($products as $product): ?>
                    <option value="<?= $product['id'] ?>"><?= htmlspecialchars($product['product']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" name="quantity" id="quantity" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="request_purpose" class="form-label">Request Purpose</label>
            <textarea name="request_purpose" id="request_purpose" class="form-control" rows="3" required></textarea>
        </div>

        <div class="mb-3">
            <label for="requested_by" class="form-label">Requested By</label>
            <input type="text" name="requested_by" id="requested_by" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="email" class="form-label">Email</label>
            <input type="email" name="email" id="email" class="form-control" required>
        </div>

        <div class="mb-3">
            <label for="office_name" class="form-label">Office Name</label>
            <input type="text" name="office_name" id="office_name" class="form-control">
        </div>

        <div class="mb-3">
            <label for="request_date" class="form-label">Request Date</label>
            <input type="date" name="request_date" id="request_date" class="form-control">
        </div>

        <button type="submit" class="btn btn-success">Submit Request</button>
    </form>
</div>

<script src="../JS/bootstrap.min.js"></script>
</body>
</html>
