<?php
session_start();
include '../connection.php';

// Get the request ID from URL
if (!isset($_GET['id'])) {
    die("Invalid Request");
}
$request_id = intval($_GET['id']);

// Handle Approve/Reject actions before fetching details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['accept'])) {
        $conn->query("UPDATE requests SET status='Approved' WHERE id=$request_id");
        header("Location: UserRequest.php?msg=Request Approved Successfully");
        exit();
    } elseif (isset($_POST['reject'])) {
        $conn->query("UPDATE requests SET status='Rejected' WHERE id=$request_id");
        header("Location: UserRequest.php?msg=Request Rejected Successfully");
        exit();
    }
}

// Fetch request details
$query = "SELECT * FROM requests WHERE id = $request_id";
$result = $conn->query($query);

if (!$result || $result->num_rows == 0) {
    die("Request not found.");
}

$request = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <div class="card shadow-sm">
        <div class="card-body">
            <h4 class="card-title mb-3"><b>Request Details</b></h4>

            <p><b>Product Name:</b> <?= htmlspecialchars($request['product_name']); ?></p>
            <p><b>Quantity:</b> <?= htmlspecialchars($request['quantity']); ?></p>
            <p><b>Purpose:</b> <?= htmlspecialchars($request['request_purpose']); ?></p>
            <p><b>Requested By:</b> <?= htmlspecialchars($request['requested_by']); ?></p>
            <p><b>Email:</b> <?= htmlspecialchars($request['email']); ?></p>
            <p><b>Office:</b> <?= htmlspecialchars($request['office_name']); ?></p>
            <p><b>Request Date:</b> <?= htmlspecialchars($request['request_date']); ?></p>
            <p><b>Status:</b> 
                <span class="badge 
                    <?php 
                    if(strtolower($request['status'])=='pending') echo 'bg-warning';
                    elseif(strtolower($request['status'])=='approved') echo 'bg-success';
                    elseif(strtolower($request['status'])=='rejected') echo 'bg-danger';
                    else echo 'bg-secondary';
                    ?>">
                    <?= htmlspecialchars($request['status']); ?>
                </span>
            </p>

            <!-- Approve/Reject Buttons (always visible) -->
            <form method="post" class="mt-3">
                <button type="submit" name="accept" class="btn btn-success"
                    <?= strtolower($request['status']) !== 'pending' ? 'disabled' : '' ?>>
                    ✅ Approve
                </button>
                <button type="submit" name="reject" class="btn btn-danger"
                    <?= strtolower($request['status']) !== 'pending' ? 'disabled' : '' ?>>
                    ❌ Reject
                </button>
            </form>

            <a href="UserRequest.php" class="btn btn-secondary mt-3">⬅ Back</a>
        </div>
    </div>
</div>

</body>
</html>
