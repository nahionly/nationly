<?php
// manager_pending.php
session_start();
include 'connection.php'; // your mysqli connection file

// Check login
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Check if user is a manager
if ($_SESSION['role'] !== 'manager') {
    http_response_code(403);
    echo "Forbidden";
    exit();
}

$userId = $_SESSION['user_id'];
$onlyMine = !empty($_GET['only_mine']) ? true : false;

// Fetch pending requests
if ($onlyMine) {
    $sql = "SELECT r.*, u.name AS submitter_name 
            FROM requests r 
            JOIN users u ON r.submitter_id=u.id 
            WHERE r.status='pending' 
              AND (r.assignee_id=? OR r.assignee_id IS NULL) 
            ORDER BY r.created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
} else {
    $sql = "SELECT r.*, u.name AS submitter_name 
            FROM requests r 
            JOIN users u ON r.submitter_id=u.id 
            WHERE r.status='pending' 
            ORDER BY r.created_at DESC";
    $result = $conn->query($sql);
}

?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Pending Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-3">

<h2>Pending Requests</h2>
<p>
  <a href="manager_pending.php" class="btn btn-sm btn-primary">All Pending</a>
  <a href="manager_pending.php?only_mine=1" class="btn btn-sm btn-success">Assigned to Me / Unassigned</a>
</p>

<table class="table table-bordered table-striped">
  <thead class="table-dark">
    <tr>
      <th>ID</th>
      <th>Title</th>
      <th>Type</th>
      <th>Submitter</th>
      <th>Priority</th>
      <th>Created</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
  <?php if ($result && $result->num_rows > 0): ?>
    <?php while ($r = $result->fetch_assoc()): ?>
      <tr>
        <td><?= htmlspecialchars($r['id']) ?></td>
        <td><?= htmlspecialchars($r['title']) ?></td>
        <td><?= htmlspecialchars($r['type']) ?></td>
        <td><?= htmlspecialchars($r['submitter_name']) ?></td>
        <td><?= htmlspecialchars($r['priority']) ?></td>
        <td><?= htmlspecialchars($r['created_at']) ?></td>
        <td><a href="view_request.php?id=<?= $r['id'] ?>" class="btn btn-sm btn-info">View</a></td>
      </tr>
    <?php endwhile; ?>
  <?php else: ?>
      <tr><td colspan="7" class="text-center">No pending requests found.</td></tr>
  <?php endif; ?>
  </tbody>
</table>

</body>
</html>
