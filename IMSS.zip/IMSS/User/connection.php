<?php
// connection.php

$host = "localhost";
$user = "root";
$pass = "";
$db   = "inventory_system"; // your actual database name

// Create connection
$conn = new mysqli($host, $user, $pass, $db);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Now $conn can be used for all queries with mysqli
?>
