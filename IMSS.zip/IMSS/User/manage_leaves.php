<?php
session_start();
include '../connection.php'; // your DB connection

// Filter by status if requested
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Build SQL query
if ($status_filter && in_array($status_filter, ['Pending','Approved','Rejected'])) {
    $sql = "SELECT * FROM requests WHERE status='$status_filter' ORDER BY request_date DESC";
} else {
    $sql = "SELECT * FROM requests ORDER BY request_date DESC";
}

$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Manage Requests</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">

<div class="container mt-5">
    <h2>Manage Requests</h2>
    
    <!-- Filter Buttons -->
    <form method="get" class="mb-3">
        <button type="submit" name="status" value="Pending" class="btn btn-warning">Pending</button>
        <button type="submit" name="status" value="Approved" class="btn btn-success">Approved</button>
        <button type="submit" name="status" value="Rejected" class="btn btn-danger">Rejected</button>
        <a href="manage_leaves.php" class="btn btn-secondary">All</a>
    </form>

    <table class="table table-bordered table-hover text-center">
        <thead class="table-dark">
            <tr>
                <th>S No</th>
                <th>Product</th>
                <th>Quantity</th>
                <th>Purpose</th>
                <th>Requested By</th>
                <th>Email</th>
                <th>Office</th>
                <th>Request Date</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if ($result && $result->num_rows > 0) {
                $sno = 1;
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>".$sno++."</td>
                        <td>".htmlspecialchars($row['product_name'])."</td>
                        <td>".htmlspecialchars($row['quantity'])."</td>
                        <td>".htmlspecialchars($row['request_purpose'])."</td>
                        <td>".htmlspecialchars($row['requested_by'])."</td>
                        <td>".htmlspecialchars($row['email'])."</td>
                        <td>".htmlspecialchars($row['office_name'])."</td>
                        <td>".htmlspecialchars($row['request_date'])."</td>
                        <td>";
                    
                    if ($row['status'] == 'Pending') echo "<span class='badge bg-warning text-dark'>Pending</span>";
                    elseif ($row['status'] == 'Approved') echo "<span class='badge bg-success'>Approved</span>";
                    elseif ($row['status'] == 'Rejected') echo "<span class='badge bg-danger'>Rejected</span>";
                    else echo "<span class='badge bg-secondary'>Unknown</span>";

                    echo "</td>
                        <td>
                            <a href='leave_details.php?id=".$row['id']."' class='btn btn-info btn-sm'>View</a>
                        </td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='10'>No records found</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

</body>
</html>
