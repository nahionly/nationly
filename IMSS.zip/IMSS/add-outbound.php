<?php

include 'connection.php';
header("Cache-Control: no-cache, must-revalidate");

// --- Handle AJAX requests --- //
if(isset($_GET['action'])){
    $action = $_GET['action'];

    // ✅ Fetch products for autocomplete
    if($action === 'getProducts'){
        $res = mysqli_query($conn, "SELECT id, product, price FROM products ORDER BY product ASC");
        $products = [];
        while($row = mysqli_fetch_assoc($res)){
            $products[] = $row;
        }
        echo json_encode($products);
        exit;
    }

    // ✅ Fetch sales table
    if($action === 'getSales'){
        $res = mysqli_query($conn, "SELECT s.id, p.product, p.price, s.quantity, s.total, s.sale_date 
                                    FROM sales s 
                                    JOIN products p ON s.product_id = p.id 
                                    ORDER BY s.sale_date DESC");
        $sales = [];
        while($row = mysqli_fetch_assoc($res)){
            $sales[] = $row;
        }
        echo json_encode($sales);
        exit;
    }
}

// --- Handle new outbound submission --- //
if($_SERVER['REQUEST_METHOD'] === 'POST'){
    $product_id = intval($_POST['product_id']);
    $quantity   = intval($_POST['quantity']);

    if($product_id > 0 && $quantity > 0){
        $product = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM products WHERE id=$product_id"));
        if($product){
            $total = $product['price'] * $quantity;
            $date = date('Y-m-d H:i:s');
            mysqli_query($conn, "INSERT INTO sales (product_id, quantity, total, sale_date) 
                                 VALUES ($product_id, $quantity, $total, '$date')");
            echo "success";
            exit;
        }
    }
    echo "error";
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Add Outbound Product | Inventory System</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<link rel="stylesheet" href="./CSS/dashboard-style.css">
<style>
    .autocomplete-suggestions {
        border: 1px solid #ccc;
        background: #fff;
        max-height: 200px;
        overflow-y: auto;
        position: absolute;
        z-index: 9999;
        width: 100%;
    }
    .autocomplete-suggestion {
        padding: 8px;
        cursor: pointer;
    }
    .autocomplete-suggestion:hover {
        background: #f0f0f0;
    }
</style>
</head>
<body>
<div class="d-flex">

<!-- Sidebar -->
<nav class="sidebar text-white vh-100">
    <div class="sidebar-header bg-light p-3">
        <h5 class="mb-0 text-dark">INVENTORY SYSTEM</h5>
    </div>
    <ul class="nav flex-column mt-3">
        <li class="nav-item"><a href="dashboard.php" class="nav-link text-white"><i class="fas fa-home me-2"></i> Dashboard</a></li>
<li class="nav-item">
            <a class="nav-link text-white" data-bs-toggle="collapse" href="#userMenu" role="button" aria-expanded="false" aria-controls="userMenu">
                <i class="fas fa-user me-2"></i> User Management
                <i class="fas fa-caret-down float-end"></i>
            </a>
            <div class="collapse" id="userMenu">
                <ul class="nav flex-column ms-3">
                    <li class="nav-item"><a href="manage-group.php" class="nav-link text-white">Manage Group</a></li>
                    <li class="nav-item"><a href="manage-users.php" class="nav-link text-white">Manage Users</a></li>
                </ul>
            </div>
        </li>        
        <li class="nav-item"><a href="categories.php" class="nav-link text-white"><i class="fas fa-layer-group me-2"></i> Categories</a></li>
        <li class="nav-item"><a href="products.php" class="nav-link text-white"><i class="fas fa-box me-2"></i> Products</a></li>
        <li class="nav-item"><a href="media-files.php" class="nav-link text-white"><i class="fas fa-image me-2"></i> Media Files</a></li>
        <li class="nav-item"><a href="manage-outbound.php" class="nav-link text-whiteactive"><i class="fas fa-shopping-cart me-2"></i> Outbound Products</a></li>
        <li class="nav-item"><a href="outbound-report.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Outbound Report</a></li>
        <li class="nav-item"><a href="./User/UserRequest.php" class="nav-link text-white"><i class="fas fa-file-alt me-2"></i> Request</a></li>

    </ul>
</nav>
  <!-- Main Content -->
  <div class="p-4 flex-grow-1">
    <h4 class="fw-bold">Add Outbound Product</h4>

    <!-- Outbound Form -->
    <form id="outboundForm">
        <div class="mb-3 position-relative">
            <label for="product_search" class="form-label">Search Product</label>
            <input type="text" class="form-control" id="product_search" placeholder="Type product name..." autocomplete="off" required>
            <input type="hidden" name="product_id" id="product_id">
            <div id="suggestions" class="autocomplete-suggestions"></div>
        </div>

        <div class="mb-3">
            <label for="quantity" class="form-label">Quantity</label>
            <input type="number" name="quantity" id="quantity" class="form-control" min="1" required>
        </div>

        <button type="submit" class="btn btn-primary"><i class="fas fa-plus"></i> Add Outbound</button>
    </form>

    <!-- Outbound Records Table -->
    <div class="mt-4">
        <h5 class="fw-bold">Outbound Records</h5>
        <table class="table table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>Item</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Total</th>
                    <th>Date</th>
                </tr>
            </thead>
            <tbody id="salesTable">
                <tr><td colspan="5" class="text-center">Loading...</td></tr>
            </tbody>
        </table>
    </div>
  </div>
</div>

<script>
let products = [];
const input = document.getElementById('product_search');
const suggestions = document.getElementById('suggestions');
const product_id_input = document.getElementById('product_id');

// ✅ Load products for autocomplete
fetch('add-outbound.php?action=getProducts')
    .then(res => res.json())
    .then(data => { products = data; });

// ✅ Autocomplete
input.addEventListener('input', function(){
    const value = this.value.toLowerCase();
    suggestions.innerHTML = '';
    if(value){
        const filtered = products.filter(p => p.product.toLowerCase().includes(value));
        filtered.forEach(p => {
            const div = document.createElement('div');
            div.classList.add('autocomplete-suggestion');
            div.textContent = p.product;
            div.dataset.id = p.id;
            div.addEventListener('click', function(){
                input.value = p.product;
                product_id_input.value = p.id;
                suggestions.innerHTML = '';
            });
            suggestions.appendChild(div);
        });
    }
});

document.addEventListener('click', function(e){
    if(e.target !== input){
        suggestions.innerHTML = '';
    }
});

// ✅ Handle form submission
document.getElementById('outboundForm').addEventListener('submit', function(e){
    e.preventDefault();
    const formData = new FormData(this);
    fetch('add-outbound.php', { method: 'POST', body: formData })
    .then(res => res.text())
    .then(data => {
        if(data.trim() === 'success'){
            this.reset();
            product_id_input.value = '';
            loadSales();
        } else {
            alert('Error adding outbound product.');
        }
    });
});

// ✅ Load sales table
function loadSales(){
    fetch('add-outbound.php?action=getSales')
        .then(res => res.json())
        .then(data => {
            const table = document.getElementById('salesTable');
            table.innerHTML = '';
            if(data.length === 0){
                table.innerHTML = '<tr><td colspan="5" class="text-center">No outbound records</td></tr>';
            } else {
                data.forEach(s => {
                    table.innerHTML += `
                        <tr>
                            <td>${s.product}</td>
                            <td>${s.price}</td>
                            <td>${s.quantity}</td>
                            <td>${s.total}</td>
                            <td>${s.sale_date}</td>
                        </tr>
                    `;
                });
            }
        });
}

// Load on page start
loadSales();
</script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
