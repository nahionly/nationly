<?php
session_start();
include 'connection.php';

$msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_title = trim($_POST['product_title']);
    $category_id   = !empty($_POST['category_id']) ? intval($_POST['category_id']) : null;
    $quantity      = intval($_POST['quantity']);
    $buying_price  = floatval($_POST['buying_price']);
    $selling_price = floatval($_POST['selling_price']); // ✅ make sure this is saved

    // Handle image upload
    $image_path = null;
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }
        $filename = time() . "_" . basename($_FILES['image']['name']);
        $target_file = $target_dir . $filename;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image_path = $target_file;
        }
    }

    // Insert into products table
    $sql = "INSERT INTO products (product, category_id, quantity, buying_price, selling_price, image_path, created_at) 
            VALUES (?, ?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("siidds", $product_title, $category_id, $quantity, $buying_price, $selling_price, $image_path);

    if ($stmt->execute()) {
        header("Location: products.php?msg=added");
        exit();
    } else {
        $msg = "Error: " . $stmt->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Add Product</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
  <div class="container">
    <h3>Add Product</h3>
    <?php if($msg): ?>
      <div class="alert alert-danger"><?= $msg ?></div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
        <label class="form-label">Product Title</label>
        <input type="text" name="product_title" class="form-control" required>
      </div>

      <div class="mb-3">
        <label class="form-label">Category</label>
        <select name="category_id" class="form-select">
          <option value="">-- Select Category --</option>
          <?php
          $res = $conn->query("SELECT * FROM categories ORDER BY name");
          while($c = $res->fetch_assoc()):
          ?>
            <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
          <?php endwhile; ?>
        </select>
      </div>

      <div class="row">
        <div class="col-md-4 mb-3">
          <label class="form-label">Quantity</label>
          <input type="number" name="quantity" class="form-control" required>
        </div>
        <div class="col-md-4 mb-3">
          <label class="form-label">Buying Price</label>
          <input type="number" step="0.01" name="buying_price" class="form-control" required>
        </div>
        <div class="col-md-4 mb-3">
          <label class="form-label">Selling Price</label>
          <input type="number" step="0.01" name="selling_price" class="form-control" required>
        </div>
      </div>

      <div class="mb-3">
        <label class="form-label">Product Image</label>
        <input type="file" name="image" class="form-control">
      </div>

      <button type="submit" class="btn btn-success">Save Product</button>
      <a href="products.php" class="btn btn-secondary">Back</a>
    </form>
  </div>
</body>
</html>
