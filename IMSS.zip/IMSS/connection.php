
<?php
$servername = "localhost";
$username   = "root";      // default in WAMP
$password   = "";          // check if empty or set in phpMyAdmin
$dbname     = "inventory_system";      // replace with your DB name

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>