<?php
include 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['group_name']);
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);

    $sql = "INSERT INTO groups (group_name,username, password, description)
     VALUES ('$name','$username','$password',  '$description')";
    if (mysqli_query($conn, $sql)) {
        header("Location: manage-group.php");
        exit();
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Group</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="p-4">

<div class="container">
    <h2>Add Group</h2>
    <form method="POST">
        <div class="mb-3">
            <label>Group Name</label>
            <input type="text" name="group_name" class="form-control" required>
        </div>
         <div class="mb-3">
            <label>Username</label>
            <input type="text" name="username" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Password</label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Description</label>
            <textarea name="description" class="form-control"></textarea>
        </div>
        <button type="submit" class="btn btn-success">Save</button>
        <a href="manage-group.php" class="btn btn-secondary">Cancel</a>
    </form>
</div>

</body>
</html>
