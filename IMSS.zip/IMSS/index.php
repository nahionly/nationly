<?php
session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: index.php"); // Redirect if already logged in
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Adama City Administration Inventory Management System</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link rel="stylesheet" href="./CSS/style.css">
</head>
<body class="home-body">

    <div class="home-card">
        <h1><i class="fas fa-box"></i> Adama City Administration Inventory Management System</h1>
        <p class="mb-4">Welcome! Please login to continue.</p>
        
      <div class="d-flex justify-content-center gap-4 mt-4">
    
  

           <a href="http://localhost/imss/admin/login.php" class="btn btn-danger btn-custom">
               <i class="fas fa-user-shield"></i>   .Registrar
            <a href="http://localhost/imss/user/userlogin.php" class="btn btn-success">
                <i class="fas fa-building"></i> Office
            </a>
            <a href="login.php" class="btn btn-primary btn-custom">
                <i class="fas fa-sign-in-alt"></i> warehouse
            </a>
</div>


        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
